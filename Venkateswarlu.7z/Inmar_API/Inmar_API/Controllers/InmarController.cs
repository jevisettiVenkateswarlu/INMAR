﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using Inmar_API.Model;

namespace Inmar_API.Controllers
{
    [Route("api/Inmar")]
    [ApiController]
    public class InmarController : ControllerBase
    {
        [HttpGet]
        public OfferService GetAllProducts()
        {
            OfferService objnew = new OfferService();
            
            return objnew;
        }

        [HttpPost]
        public int AddProduct(Product reqobj)
        {
            Product newobj = new Product();
            newobj.ProductName = reqobj.ProductName;
            newobj.Price= reqobj.Price;
            newobj.Description = reqobj.Description;

            //need to add 'newobj' to the database or some where

            return 0;
        }
    }
}