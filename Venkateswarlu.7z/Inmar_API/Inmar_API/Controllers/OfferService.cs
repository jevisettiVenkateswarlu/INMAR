﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Inmar_API.Model;

namespace Inmar_API.Controllers
{
    public class OfferService
    {
        private List<Product> Inventory { get; set; }

        public OfferService()
        {            
            GetInventoryList();
        }

        private List<Product> GetInventoryList()
        {
            List<Product> newInventory = new List<Product>();
            Product objProduct = new Product();
            objProduct.ProductName = "P1";
            objProduct.Price = "1000";
            objProduct.Description = "P1 desc";
            newInventory.Add(objProduct);

            Product objProduct2 = new Product();
            objProduct2.ProductName = "P2";
            objProduct2.Price = "2000";
            objProduct2.Description = "P2 desc";
            newInventory.Add(objProduct2);

            Product objProduct3 = new Product();
            objProduct3.ProductName = "P3";
            objProduct3.Price = "4000";
            objProduct3.Description = "P3 desc";
            newInventory.Add(objProduct3);

            Product objProduct4 = new Product();
            objProduct4.ProductName = "P4";
            objProduct4.Price = "7000";
            objProduct4.Description = "P4 desc";
            newInventory.Add(objProduct4);

            Product objProduct5 = new Product();
            objProduct5.ProductName = "P5";
            objProduct5.Price = "6000";
            objProduct5.Description = "P5 desc";
            newInventory.Add(objProduct5);

            Product objProduct6 = new Product();
            objProduct6.ProductName = "P6";
            objProduct6.Price = "8000";
            objProduct6.Description = "P6 desc";
            newInventory.Add(objProduct6);
            return newInventory;

        }

         
    }
}
