﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Inmar_API.Model;
namespace Inmar_API.Model
{
    public class Offer
    {
        Offer()
        {

        }

        public string OfferName { get; set; }
        public List<Product> listProducts { get; set; }
    }
}
