using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inmar_Logical
{
    class Program
    {
        static void Main(string[] args)
        {
            //@Division check
            DiviCheck();
            Console.WriteLine("--------------------------------");
            //@String reverese
            StringReverse("abcdef");

            Console.ReadLine();

        }

        public static void DiviCheck()
        {
            try
            {
                for (int i = 1; i < 100; i++)
                {
                    if (i % 3 == 0 && i % 5 == 0)
                    {
                        Console.WriteLine("I :" + i + "- fizzbuzz");
                        continue;
                    }
                    if (i % 3 == 0)
                    {
                        Console.WriteLine("I :" + i + "- fizz");
                        continue;
                    }
                    if (i % 5 == 0)
                    {
                        Console.WriteLine("I :" + i + "- buzz");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public static void StringReverse(string MainString)
        {
            string Reverse = string.Empty;
            Console.WriteLine("Main String    : " + MainString);

            try
            {
                char[] strchar = MainString.ToCharArray();
                for (int i = strchar.Length - 1; i > -1; i--)
                {
                    Reverse = Reverse + strchar[i];
                }
                Console.WriteLine("String Reverese: " + Reverse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
